
public class Prog2Driver {

    public static void main(String[] args) {
        Prog2Pack3 p2p3 = new Prog2Pack3();
        Inter1Prog2 i1p2 = p2p3.getObj();
        i1p2.interDisplay();
    }

}
