
public class Prog2 {
    protected class InnerProg2 implements Inter1Prog2 {
        public InnerProg2() {

        }

        public void interDisplay() {
            System.out.println("Hello");
        }
    }
}
