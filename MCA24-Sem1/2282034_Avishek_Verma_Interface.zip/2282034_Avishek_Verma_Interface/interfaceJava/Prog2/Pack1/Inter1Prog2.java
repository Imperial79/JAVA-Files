public interface Inter1Prog2 {
    public void interDisplay();
}
