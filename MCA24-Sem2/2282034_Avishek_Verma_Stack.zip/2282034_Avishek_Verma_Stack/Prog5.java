
/*5. Write a method in a separate class to convert an infix expression to its corresponding postfix expression. */

class IntoPost {

    static boolean isOperator(String ch) {
        if (ch.equals("+") || ch.equals("-") || ch.equals("*") || ch.equals("/"))
            return true;
        return false;
    }

    static int preceed(String ch) {
        switch (ch) {
            case "+":
            case "-":
                return 1;
            case "*":
            case "/":
                return 2;

            case "^":
                return 3;

        }
        return -1;
    }

    static String convert(String exp) {
        int n = exp.length(), top = -1;
        String ch = "", post = "";
        String stk[] = new String[n];
        for (int i = 0; i < n; i++) {
            ch = String.valueOf(exp.charAt(i));
            if (ch.matches("[a-zA-Z]")) {
                post += ch;
            } else if (isOperator(ch)) {

                if (top == -1) {
                    top += 1;
                    stk[top] = ch;
                }

                else {
                    while (top >= 0 && preceed(stk[top]) >= preceed(ch)) {
                        post += stk[top];
                        top -= 1;
                    }
                    top += 1;
                    stk[top] = ch;
                }
            }
        }
        for (int i = top; i > -1; i--) {
            post += stk[i];
        }
        return post;
    }
}

public class Prog5 {
    public static void main(String[] args) {
        String exp = "a+b*c+d";
        System.out.println(exp + " -> " + IntoPost.convert(exp));
    }

}
